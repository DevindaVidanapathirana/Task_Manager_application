package com.example.trucklist

data class Note(
    val id:Int,
    val title:String,
    val content:String
)
